<?php
	//  
	$urls = array('https://forms.gle/WJqbSoATNPGtEZ8K8', 'https://forms.gle/8FA5y4wyetesTUr9A', 'https://forms.gle/Eq8qgciPNwtzwcbr6', 'https://forms.gle/WfW5Qw8yeMLssZaZ9');
	$idx = array_rand($urls);
	// $idx = rand(0, count($urls) - 1)
	$target_url = $urls[$idx];

	// PHP permanent URL redirection
	header("Location: " . $target_url, true, 301);
	exit();
?>