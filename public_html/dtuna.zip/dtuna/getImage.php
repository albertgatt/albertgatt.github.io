<?php
header( "Content-type: image/gif" );
$id = $_REQUEST['id'];
$domain = $_REQUEST['domain'];

if( $id == 'blank' )
  {
    return "";
  }

//establish DB link
require('dbSetup.php');
$link = mysql_connect( SERVER, USERNAME, PASSWORD );
if ( !$link ) 
  {
    echo "<h1>Error reading database. Please try again later.</h1>";
    exit;
  } 
mysql_select_db( DB, $link ) 
  || die( '<h1>Error connecting to database. Please try later.</h1>' );


$imageQuery = "SELECT image FROM $domain WHERE imageID = $id";
$result = mysql_query( $imageQuery, $link );
if( !$result )
  {
    die( "Error retrieving image: " . mysql_error() );
  }
$image = mysql_result( $result, 0 );
stripslashes( $image );
mysql_close($link);
echo $image;
?>

