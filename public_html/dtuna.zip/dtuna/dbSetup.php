<?php
//EDIT THE FIRST THREE CONSTANTS - insert values between the empty quotes
define ( "SERVER", "webhost-sql"); //YOUR SERVER, e.g. localhost
define( "USERNAME", "agat1-sql" ); //Your username, e.g. root
define( "PASSWORD", "alb479" ); //your password
define("DB", "agat1-db"); //your DB name

//DO NOT CHANGE THE BELOW
define( "NUM_TRIALS", 40); //TOTAL NO OF TRIALS
define( "FIRST_TRIAL", 101); //FIRST ACTUAL TRIAL (after prelim phases)

class PhaseHandler {
	/*
		This class just handles the phases of the experiment, from start to finish.
	*/
	static $PHASES = array("start", "demographics", "instructions", 101, 102, 103, 104, 1, 2, 
							3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 
							21, 22,23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 
							37, 38, 39, 40, "debriefing");

	static $PRACTICE_PHASES = array(101, 102, 103, 104);				
							
	public static function isPracticeTrial( $number ) {
		return in_array($number, self::$PRACTICE_PHASES);
	}

	public static function isFinalTrial($number) {
		return $number == NUM_TRIALS;
	}

	public static function getNextPhase($phase) {				
		$i = -1;
		
		foreach(self::$PHASES as $p) {
			$i++;
			if( $p == $phase) {
				break;		
			}
		}				
		
		return self::$PHASES[$i+1];
	}

	public static function isTextInputCondition($condition) {
		return $condition == "baseline";
	}

	public static function getInstructionsFile($condition) {
		return $condition . ".instructions.inc";
	}

	public static function getPracticeTrialFile($condition) {
		return $condition . ".practice.inc";
	}

	public static function getTrialFile($condition) {
		return "trial.inc";
	}


}

?>