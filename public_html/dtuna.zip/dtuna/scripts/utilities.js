//focus the description box if available
function focusDescription() {
	if(document.forms.trial.description) {
		document.forms.trial.description.focus();
	}
}

//open new exp window
function openNewWindow(form) {
	
	if(checkPassword(form.password.value)) {
		var phase = form.phase.value;
		var condition = getRadioValue(form.condition);
		var url = "index.php?phase=" + phase + "&condition=" + condition;
		window.open(url, "Experiment", "toolbar=0, status=0, resizable=1");
	} 
	
	return false;
	
}

//get value of radio button
function getRadioValue(element) {
for (var i=0; i < element.length; i++)  {
   if (element[i].checked) {
      return element[i].value;
      }
   }
}



//make an image disappear
function removeImage( img ) {
  img.style.visibility = 'hidden';
}

//check a user-entered password
function checkPassword(pass) {
	var password="kvd";
	return (pass == password);
}

//combined check and submit function
function checkAndSubmit( form ) {
	//non-baseline conditions, we just continue
	if(form.condition.value != "baseline") {
		return true;
		
	//baseline condition we validate
 	} else {
      return validateForm(form);    
    }
}


// validates that the field value string has one or more characters in it
function isNotEmpty( elem ) {
  var str = elem.value;
  if(str == null || str.length == 0 || str == 'Choose one') 
    {
      return false;
    } 
  return true;
}


//generic function to validate a form
function validateForm( form ) {
  var radioNames = new Array( );
  var r = -1;
  var checkedRadios = new Array( );
  for ( var i = 0; i < form.elements.length; i++ )
    {
      currentElement = form.elements[i];
      if( currentElement.name == 'comments' ) {
	continue;
      }
      if ( (currentElement.type == 'text') || (currentElement.type == 'select-one') || currentElement.type == 'textarea')
	{
	  if( !isNotEmpty( currentElement ) )
	    {
	      alert( 'Some information is missing.' );
	      return false;
	    }
	}
      else if ( currentElement.type == 'radio' )
	{
	  r++;
	  radioNames[r] = currentElement.name;
	  if ( currentElement.checked )
	    {
	      checkedRadios[currentElement.name] = 1;
	    }
	}
    }
  for ( var j = 0; j < radioNames.length; j++ )
    {
      var name = radioNames[j];
      if ( checkedRadios[name] != 1 )
	{
	  alert( 'Some information is missing.' );
	  return false;
	}
    }

  return true;
}

//time a session: start timer
function startTimer( formName ) {
  date = new Date();
  document.getElementById(formName).elements['time'].value = date.getTime();
}

//end timer
function endTimer( formName ) {
  timeToChoice = new Date();
  startTime = document.getElementById(formName).elements['time'].value;
  seconds = (timeToChoice.getTime() - startTime)/1000;
  document.getElementById(formName).elements['time'].value = seconds;
}


//block submissions from the enter button
function blockEnter(evt) {
    evt = (evt) ? evt : event;
    var charCode = (evt.charCode) ? evt.charCode :
        ((evt.which) ? evt.which : evt.keyCode);
    if (charCode == 13 || charCode == 3) {
        return false;
    } else {
        return true;
    }
}


//the procedure to give feedback
function startFeedbackProcedure( param ) {
  j = 0;
  for( var i = 0; i < document.images.length; i++ )
    {
      if( j == 2 )
	{
	  break;
	}
      curr = document.images[i];
      if( param == 1 && curr.id == 'target' )
	{
	  hideImage( curr );
	  j++;
	}
      else if( param == 0 && curr.id == 'distractor' )
	{
	  hideImage( curr );
	  j++;
	}
    }
  document.getElementById( 'show' ).style.display = 'block';
}

function hideImage( img ) {
  try {
    img.style.visibility = "hidden";
  }
  catch( Exception ) {
  }
}

