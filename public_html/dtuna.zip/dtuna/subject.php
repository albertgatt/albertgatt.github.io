<?php
require_once("dbSetup.php");
require_once( "trial.php" );

//----------------------------------------------------------------------------------------------------
//Instantiates a subject class
//----------------------------------------------------------------------------------------------------

class Subject {

	var $id; //the subject's id
	var $phase; //the last phase of the experiment done by subject
	var $version; //the version of the experiment done by subject (1-15)
	var $nextPhase; //the next phase of the experiment
	var $dbLink; //database handle
	var $maxTrials;

	//constructor
	public function Subject( $phase, $condition ) {
		$this->openDB();
		$this->phase = $phase;						
		$this->nextPhase = PhaseHandler::getNextPhase($phase);
		$this->version = $condition;
		$this->maxTrials = NUM_TRIALS;

		switch( $this->phase )
		{
			case "start":
				$this->getNewID();
				break;

			case "demographics":
				$this->id = $_POST['subjectID'];
				$this->enterLogData();
				$this->randomiseTrials();
				$this->prepareResultsRow();
				break;

			default:
				$this->id = $_POST['subjectID'];
				break;
		}
	} //END CONSTRUCTOR


	//open link to DB
	private function openDB() {
		$link = mysql_connect( SERVER, USERNAME, PASSWORD );

		if ( !$link ) {
			echo "<h1>Error reading database. Please try again later.</h1>";
			exit;
		} else	{
			$this->dbLink = $link;
		}

		mysql_select_db( DB, $this->dbLink )
		|| die( '<h1>Error connecting to database. Please try later.</h1>' );
	}


	//insert new subject data
	private function enterLogData()  {
		$gender = addslashes( $_POST['gender'] );
		$age = addslashes( $_POST['age'] );
		$colBlind = addslashes($_POST['colour']);
		$timestamp = time();
		$date = date('Y-m-d H:i:s', substr($timestamp, 0, -3));

		$newSubjectQuery = "INSERT INTO tunaLOG values( $this->id, '$date', '$this->version',
		'$gender', $age, '$colBlind' )";

		mysql_query( $newSubjectQuery, $this->dbLink )
		|| die( "The system could not log your information: " . mysql_error() );
	}


	//create a random order of trials
	private function randomiseTrials() {
		//create new randomised in tunaRANDOM
		$allTrials = range(1, NUM_TRIALS);
		srand((float)microtime() * 1000000);
		shuffle( $allTrials );
		$pQuery = implode( ",", PhaseHandler::$PRACTICE_PHASES);
		$tQuery = implode( ",", $allTrials );
		$randQuery = "INSERT INTO tunaRANDOM values( $this->id, ";
		$fullQuery = $randQuery . $pQuery . "," . $tQuery . " );";
		mysql_query( $fullQuery, $this->dbLink )
		|| die( "Error randomising trials: " . mysql_error() );
	}


	//prepare a new row in results table for subject
	private function prepareResultsRow() {
		if($this->version == "baseline") {
			//create a results entry
			$resQuery = "INSERT INTO tunaRESULTS VALUES( $this->id, ";
			$rQuery = implode( ",", range(1,44) );
			$query = $resQuery . $rQuery . ")";
			#echo $query;
			mysql_query( $query, $this->dbLink )
			|| die( "Unable to write to results table: " . mysql_error() );
		}
	}


	//assign new subject ID
	private function getNewID( ) {
		$toDateQuery =  "SELECT MAX(subjectID) FROM tunaLOG";
		$result = mysql_query( $toDateQuery, $this->dbLink );

		if( mysql_affected_rows() == 0 ) {
			$this->id = 1;

		} else {
			$subjectsToDate = mysql_result( $result, 0 );
			$subject = $subjectsToDate + 1;
			$this->id = $subject;
		}
	}


	//select next action: trial or debriefing
	public function nextAction() {
		switch( $this->nextPhase )
		{
			case "demographics":
				$this->newSubjectPage();
				break;
					
			case "instructions":
				$this->instruct();
				break;

			case "debriefing":
				$this->enterResult();
				$this->debrief();
				break;

			case FIRST_TRIAL:
				$this->makeNewTrial();
				break;

			default:
				$this->enterResult();
				$this->makeNewTrial();
				break;
		}
	}

	//serve a page for data from new subject
	private function newSubjectPage() {
		require('header.inc');
		require('newSubject.inc');
	}
	

	//update trial data
	private function enterResult() {
		$trialNo= $_POST['trialID'];
		$trial = 'trial' . $trialNo;
		
		if( PhaseHandler::isTextInputCondition($this->version) ) {
			$updateResultQ = "UPDATE tunaRESULTS SET $trial = '"
			. addslashes( $_POST['description'] )
			. "' WHERE subjectID=$this->id ";
			mysql_query( $updateResultQ, $this->dbLink )
			|| die( "Failed to update database with new description: " . mysql_error() );
		}
	}


	//debrief subject
	private function debrief() {
		require( "header.inc" );
		require( "debriefing.inc" );
		exit();
	}


	//send instructions
	private function instruct() {
		$instructionFile = PhaseHandler::getInstructionsFile($this->version);
		require( "header.inc" );
		require( $instructionFile );
	}


	//make a new trial for this subject
	private function makeNewTrial() {
		$isPractice = PhaseHandler::isPracticeTrial($this->nextPhase);
		$trial = new Trial( $this->id, $this->nextPhase, $this->version, $this->dbLink, $isPractice );
		$trial->serveTrial();
	}


	//close DB connection
	public function closeDB() {
		mysql_close( $this->dbLink );
	}


	//redirect subject out of experiment
	private function redirect() {
		header("Location: http://www.itri.brighton.ac.uk/research/reg08/" );
	}


} //END SUBJECT CLASS

?>







