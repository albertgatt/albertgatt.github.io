<?php
//----------------------------------------------------------------------------------------------------
//Instantiates a Trial class
//----------------------------------------------------------------------------------------------------

class Trial {
	var $subject;
	var $phase;
	var $id;
	var $version;
	var $domain;
	var $cardinality;
	var $positions = Array();
	var $images = Array(); //cached images
	var $link;
	var $practice;
	var $stringPhase;
	var $file;
	var $objectString;


	//constructor
	public function Trial( $subj, $stage, $condition, $db, $ispractice ) {
		$this->subject = $subj;
		$this->positions = range( 1, 12 );
		$this->stringPhase = 'phase' . "$stage";
		$this->phase = $stage;
		$this->link = $db;
		$this->practice = $ispractice;
		$this->version = $condition;
	}

	//serve the trial
	public function serveTrial() {
		$this->getFileName();
		$this->getTrialID();
		$this->getDomainData();
		require('header.inc');
		require( $this->file );
	}

	//get the file name to serve
	private function getFileName() {
		if($practice) {
			$this->file = PhaseHandler::getTrialFile($this->version);
		} else {
			$this->file = PhaseHandler::getTrialFile($this->version);
		}
	}

	//get the id of this trial
	private function getTrialID() {

		//get the next trial for subject
		$subjectTrialQuery = "SELECT $this->stringPhase FROM tunaRANDOM WHERE subjectID=$this->subject";
		$result = mysql_query( $subjectTrialQuery, $this->link );

		if( !$result )
		{
			die( "Error retrieving new trial: ". mysql_error() );
		}

		$id = mysql_result( $result, 0 );
		$this->id = $id;
	}

	//retrieve the domain data
	private function getDomainData() {
		//get the trial data
		$domainQuery = "SELECT domain, cardinality, target1, target2, distractor1,
                    distractor2,  distractor3, distractor4, distractor5, distractor6 
                    FROM tunaTRIALS WHERE trialID = $this->id"; 
		$domResult = mysql_query( $domainQuery, $this->link );

		if( !$domResult ) {
			die( "Error retrieving targets and distractors: " . mysql_error() );
		}

		$resultRow = mysql_fetch_array( $domResult, MYSQL_ASSOC );
		$this->domain = $resultRow['domain'];
		$this->cardinality = $resultRow['cardinality'];

		//cache the images
		$images = array($resultRow['target1'], $resultRow['target2'],
		$resultRow['distractor1'], $resultRow['distractor2'],
		$resultRow['distractor3'], $resultRow['distractor4'],
		$resultRow['distractor5'], $resultRow['distractor6']);
		$this->retrieveImages($images);

		//randomise image positions
		srand((float)microtime() * 1000000);
		$auxPositions = range( 1, 15 );
		shuffle( $auxPositions );

		$this->positions[$auxPositions[0]] = Array( 'name'=>'target',
						'size' => $this->getSize( $resultRow['target1'] ),
						'id' => $resultRow['target1'],
		);

		$target1Position = $auxPositions[0];

		if ( $resultRow['cardinality'] == 2 )
		{
			$this->positions[$auxPositions[1]] = Array( 'name'=>'target',
						    'size' => $this->getSize( $resultRow['target2'] ),
						    'id' => $resultRow['target2'],
			);
			$target2Position = $auxPositions[1];
		}
		else
		{
			$this->positions[$auxPositions[1]] = Array( 'name'=>'null',
						    'size' => 'default',
						    'id' => 0,
			);

			$target2Position = 'null';
		}

		$this->positions[$auxPositions[2]] = Array( 'name'=>'distractor',
						'size' => $this->getSize( $resultRow['distractor1'] ),
						'id' => $resultRow['distractor1'],
		);
		$this->positions[$auxPositions[3]] = Array( 'name'=>'distractor',
						'size' => $this->getSize( $resultRow['distractor2'] ),
						'id' => $resultRow['distractor2'],
		);
		$this->positions[$auxPositions[4]] = Array( 'name'=>'distractor',
						'size' => $this->getSize( $resultRow['distractor3'] ),
						'id' => $resultRow['distractor3'],
		);
		$this->positions[$auxPositions[5]] = Array( 'name'=>'distractor',
						'size' => $this->getSize( $resultRow['distractor4'] ),
						'id' => $resultRow['distractor4'],
		);
		$this->positions[$auxPositions[6]] = Array( 'name'=>'distractor',
						'size' => $this->getSize( $resultRow['distractor5'] ),
						'id' => $resultRow['distractor5'],
		);

		$this->positions[$auxPositions[7]] = Array( 'name'=>'distractor',
						'size' => $this->getSize( $resultRow['distractor6'] ),
						'id' => $resultRow['distractor6'],
		);

		for( $i = 8; $i <= count( $auxPositions ); $i++ ) {
			$this->positions[$auxPositions[$i]] = Array( 'name' => 'null',
						     'id' => '0',
						     'size'=> 'default',
			);
		}

		mysql_free_result($domResult);
	}


	//get size of image
	private function getSize( $imageID ) {

		//with people trials, image size is random (not important)
		if( $this->domain == 'people' ) {
			$dice = rand( 1,5 );
			if ( $dice > 2 ) {
				return 'small';
			}  else {
				return 'large';
			}

			//for furniture we need to find size of image
		} else {
			$sizeRes = mysql_query( "SELECT size FROM $this->domain WHERE imageID = $imageID", $this->link );

			if( !$sizeRes ) {
				die( "Error retrieving size info: " . mysql_error() );
			}

			$sizeResult = mysql_fetch_array( $sizeRes, MYSQL_ASSOC );
			$size = $sizeResult['size'];
			mysql_free_result($sizeRes);
			return $size;
		}
	}

	//get the html for an image position
	public function getImageString($span) {
		$string = "";
		$cell = $span; //the cell number
		$data = $this->positions[$span]; //the array containing the row data
		$type = $data['name']; //target or distractor
		$size = $data['size']; //image size
		$imageID = $data['id']; //image ID


		if($imageID == 0) {
			$string = '<span class="hidden"></span>';

		} else {
			$string = '<img class="' . $this->domain . $size . '" '	.
							'name="' . $cell . '" ' .
							'id="' . $type . '" ' .
							'src="' . $this->images[$imageID] . '" ' . '/>';
		}

		echo $string;
	}

	//get the heading for the trial
	public function getTrialHeading() {
		$heading = "";

		if($this->practice) {
			$heading = "<h2>Dit is een oefening.</h2>";
		} else {
			$heading = "<h2>Dit is stimulus " . $this->phase . " van de " . NUM_TRIALS;
		}

		return $heading;
	}

	//get the text box if applicable (depends on condition)
	public function getTextInputString() {
		$string = "";

		if($this->cardinality == 2) {
			$string = "<strong>Welke objecten hebben een rood kader?</strong>";
		} else {
			$string = "<strong>Welk object heeft een rood kader?</strong>";
		}



		if($this->version == "baseline") {
			$string .=
      				  "<br>" .
      				  '<textarea class="description" name="description" autocomplete="off"></textarea>'; 
		}

		return $string;
	}

	//pull out the images from DB
	private function retrieveImages($imageIDs) {
		$imageString = implode(" OR imageID=", $imageIDs);
		$imageQuery = "SELECT imageID, name FROM $this->domain WHERE( imageID = " . $imageString . ")";
		$result = mysql_query( $imageQuery, $this->link );

		if( !$result )
		{
			die( "Error retrieving image: " . mysql_error() );
		}

		while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$name = $row['name'];
			$name = substr_replace($name, 'gif', -3, 3);
			$imageID = $row['imageID'];

			if($imageID > 0) {
				$this->images[$imageID] = './img/' . $name;
			}
		}

		mysql_free_result($result);
	}


} //end class Trial

?>
