<?php
require( "subject.php" );
$phase;
$condition;

if(isset($_GET['phase']) && isset($_GET['condition'])) {
	$phase = $_GET['phase'];
	$condition = $_GET['condition'];
} else if( isset($_POST['phase']) && isset($_POST['condition'])) {
	$phase  = $_POST['phase'];
	$condition = $_POST['condition'];
}

//user has just started
if( !isset( $phase) || !isset($condition) ) {
	require( "startPage.inc" );

} else {
	$subject = new Subject( $phase, $condition);
	$subject->nextAction();
	$subject->closeDB();
}

?>
