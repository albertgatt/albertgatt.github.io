<?php

    $link = '<a'.get_target()." data-toggle=\"collapse\" href=\"' . $this->getKey() . '\" class=\"biburl\" title=\"".$this->getKey()."\" {$href}>$bibstr</a>";
    
    $link .= '<div class="collapse" id="' . $this->getKey() . '">'
    $link .= '<div class="card card-block">'
    Institute of Linguistics, Rm 111, University of Malta<br/>
  Tal-Qroqq Msida MSD2080, Malta<br />
  </div>
</div>        

?>