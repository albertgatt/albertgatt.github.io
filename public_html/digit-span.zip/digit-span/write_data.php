<?php

header("Content-Type: application/json"); 
  
$input = json_decode(file_get_contents("php://input")); 
$fname = mktime() . ".json";//generates random name
$file = fopen("save/" .$fname, 'w');//creates new file
fwrite($file, $input->data);
fclose($file);

	// if(!empty($_POST['data'])){
	// 	$data = $_POST['data'];
	// 	$fname = mktime() . ".json";//generates random name
	// 	$file = fopen("save/" .$fname, 'w');//creates new file
	// 	fwrite($file, $data);
	// 	fclose($file);
	// }
?>